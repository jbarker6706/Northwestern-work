# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 14:53:10 2019

@author: jbark
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 12:33:32 2019

@author: jbark
"""
import json
import re
from urllib.request import urlopen
from bs4 import BeautifulSoup


# list of Wikipedia URLs for topic of interest Presidents and presidential topics
urls = [
    "https://en.wikipedia.org/wiki/Thomas_Jefferson",
    ]
#url = "https://en.wikipedia.org/wiki/George_Washington"

index = 1

def build_document_json(id, url, title, body):
    document = {}
    document[title] = {
        'id': id,
        'url': url,
        'title': title,
        'body': body
    }
    jd = json.dumps(document)
    return jd;

rgx_list = ['\[[0-9a-zA-Z]*\]', '\[citation needed\]', '.mw-parser-output', '.toclimit-[0-9]*', '.toclevel-[0-9]* ul,',
           '.toclevel-6 ul', '.tmulti', '.trow', '.thumb[a-zA-Z]*', '.text-align-[a-zA-Z]*', '\{[a-zA-Z0-9\:\%\-\;\!\.\,]*\}',
            '\@media', 'all\ and\ \(max\-width\:720px\)', '.tsingle', '.theader',
           '\^[a-zA-Z0-9\:\%\-\;\!\.\,]*', '\xa0', '[1-9]*\ References', '[1-9]*\ Notes' ]

def clean_text(rgx_list, text):
    new_text = text
    for rgx_match in rgx_list:
        new_text = re.sub(rgx_match, '', new_text)
    return new_text

def getNgrams(content, n):
  content = content.split(' ')
  output = []
  for i in range(len(content)-n+1):
    output.append(content[i:i+n])
  return output

def build_json_file(url):
    html = urlopen(url)
    bs = BeautifulSoup(html, 'html.parser')
    content = bs.find('div', {'id':'mw-content-text'}).get_text()
    content = clean_text(rgx_list, content)
 
    title_list = url.split('/')
    title = title_list[len(title_list) - 1]
    print(title_list)
    print(title)
    filename = title +'.json'
    document = build_document_json(index, url, title, content)
    with open(filename, "w") as f:
        f.write(document)
    
for url in urls:
    build_json_file(url)
    if(index==24):
        index = index+2
    else:
        index = index+1
