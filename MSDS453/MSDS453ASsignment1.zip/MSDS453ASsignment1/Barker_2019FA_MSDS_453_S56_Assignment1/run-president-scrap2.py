# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 11:14:22 2019

@author: jbark
"""

import json
import re
from urllib.request import urlopen
from bs4 import BeautifulSoup


# list of Wikipedia URLs for topic of interest Presidents and presidential topics
urls = [
    "https://en.wikipedia.org/wiki/George_Washington",
    "https://en.wikipedia.org/wiki/John_Adams",
    "https://en.wikipedia.org/wiki/Thomas_Jefferson",
    "https://en.wikipedia.org/wiki/James_Madison",
    "https://en.wikipedia.org/wiki/James_Monroe",
    "https://en.wikipedia.org/wiki/John_Quincy_Adams",
    "https://en.wikipedia.org/wiki/Andrew_Jackson",
    "https://en.wikipedia.org/wiki/Martin_Van_Buren",
    "https://en.wikipedia.org/wiki/William_Henry_Harrison",
    "https://en.wikipedia.org/wiki/John_Tyler",
    "https://en.wikipedia.org/wiki/James_K._Polk",
    "https://en.wikipedia.org/wiki/Zachary_Taylor",
    "https://en.wikipedia.org/wiki/Millard_Fillmore",
    "https://en.wikipedia.org/wiki/Franklin_Pierce",
    "https://en.wikipedia.org/wiki/James_Buchanan",
    "https://en.wikipedia.org/wiki/Abraham_Lincoln",
    "https://en.wikipedia.org/wiki/Andrew_Johnson",
    "https://en.wikipedia.org/wiki/Ulysses_S._Grant",
    "https://en.wikipedia.org/wiki/Rutherford_B._Hayes",
    "https://en.wikipedia.org/wiki/James_A._Garfield",
    "https://en.wikipedia.org/wiki/Chester_A._Arthur",
    "https://en.wikipedia.org/wiki/Grover_Cleveland",
    "https://en.wikipedia.org/wiki/Benjamin_Harrison",
    "https://en.wikipedia.org/wiki/William_McKinley",
    "https://en.wikipedia.org/wiki/Theodore_Roosevelt",
    "https://en.wikipedia.org/wiki/William_Howard_Taft",
    "https://en.wikipedia.org/wiki/Woodrow_Wilson",
    "https://en.wikipedia.org/wiki/Warren_G._Harding",
    "https://en.wikipedia.org/wiki/Calvin_Coolidge",
    "https://en.wikipedia.org/wiki/Herbert_Hoover",
    "https://en.wikipedia.org/wiki/Franklin_D._Roosevelt",
    "https://en.wikipedia.org/wiki/Harry_S._Truman",
    "https://en.wikipedia.org/wiki/Dwight_D._Eisenhower",
    "https://en.wikipedia.org/wiki/John_F._Kennedy",
    "https://en.wikipedia.org/wiki/Lyndon_B._Johnson",
    "https://en.wikipedia.org/wiki/Richard_Nixon",
    "https://en.wikipedia.org/wiki/Gerald_Ford",
    "https://en.wikipedia.org/wiki/Jimmy_Carter",
    "https://en.wikipedia.org/wiki/Ronald_Reagan",
    "https://en.wikipedia.org/wiki/George_H._W._Bush",
    "https://en.wikipedia.org/wiki/Bill_Clinton",
    "https://en.wikipedia.org/wiki/George_W._Bush",
    "https://en.wikipedia.org/wiki/Barack_Obama",
    "https://en.wikipedia.org/wiki/Donald_Trump",
    "https://en.wikipedia.org/wiki/Martha_Washington",
    "https://en.wikipedia.org/wiki/Abigail_Adams",
    "https://en.wikipedia.org/wiki/Martha_Jefferson_Randolph",
    "https://en.wikipedia.org/wiki/Dolley_Madison",
    "https://en.wikipedia.org/wiki/Elizabeth_Monroe",
    "https://en.wikipedia.org/wiki/Louisa_Adams",
    "https://en.wikipedia.org/wiki/Emily_Donelson",
    "https://en.wikipedia.org/wiki/Sarah_Yorke_Jackson",
    "https://en.wikipedia.org/wiki/Angelica_Singleton_Van_Buren",
    "https://en.wikipedia.org/wiki/Anna_Harrison",
    "https://en.wikipedia.org/wiki/Jane_Irwin_Harrison",
    "https://en.wikipedia.org/wiki/Letitia_Christian_Tyler",
    "https://en.wikipedia.org/wiki/Priscilla_Cooper_Tyler",
    "https://en.wikipedia.org/wiki/Julia_Gardiner_Tyler",
    "https://en.wikipedia.org/wiki/Sarah_Childress_Polk",
    "https://en.wikipedia.org/wiki/Margaret_Taylor",
    "https://en.wikipedia.org/wiki/Abigail_Fillmore",
    "https://en.wikipedia.org/wiki/Jane_Pierce",
    "https://en.wikipedia.org/wiki/Harriet_Lane",
    "https://en.wikipedia.org/wiki/Mary_Todd_Lincoln",
    "https://en.wikipedia.org/wiki/Eliza_McCardle_Johnson",
    "https://en.wikipedia.org/wiki/Julia_Grant",
    "https://en.wikipedia.org/wiki/Lucy_Webb_Hayes",
    "https://en.wikipedia.org/wiki/Lucretia_Garfield",
    "https://en.wikipedia.org/wiki/Mary_Arthur_McElroy",
    "https://en.wikipedia.org/wiki/Rose_Cleveland",
    "https://en.wikipedia.org/wiki/Frances_Cleveland",
    "https://en.wikipedia.org/wiki/Caroline_Harrison",
    "https://en.wikipedia.org/wiki/Mary_Harrison_McKee",
    "https://en.wikipedia.org/wiki/Ida_Saxton_McKinley",
    "https://en.wikipedia.org/wiki/Edith_Roosevelt",
    "https://en.wikipedia.org/wiki/Helen_Herron_Taft",
    "https://en.wikipedia.org/wiki/Ellen_Axson_Wilson",
    "https://en.wikipedia.org/wiki/Margaret_Woodrow_Wilson",
    "https://en.wikipedia.org/wiki/Margaret_Woodrow_Wilson",
    "https://en.wikipedia.org/wiki/Edith_Wilson",
    "https://en.wikipedia.org/wiki/Florence_Harding",
    "https://en.wikipedia.org/wiki/Grace_Coolidge",
    "https://en.wikipedia.org/wiki/Lou_Henry_Hoover",
    "https://en.wikipedia.org/wiki/Eleanor_Roosevelt",
    "https://en.wikipedia.org/wiki/Bess_Truman",
    "https://en.wikipedia.org/wiki/Mamie_Eisenhower",
    "https://en.wikipedia.org/wiki/Jacqueline_Kennedy_Onassis",
    "https://en.wikipedia.org/wiki/Lady_Bird_Johnson",
    "https://en.wikipedia.org/wiki/Pat_Nixon",
    "https://en.wikipedia.org/wiki/Betty_Ford",
    "https://en.wikipedia.org/wiki/Rosalynn_Carter",
    "https://en.wikipedia.org/wiki/Nancy_Reagan",
    "https://en.wikipedia.org/wiki/Barbara_Bush",
    "https://en.wikipedia.org/wiki/Hillary_Clinton",
    "https://en.wikipedia.org/wiki/Laura_Bush",
    "https://en.wikipedia.org/wiki/Michelle_Obama",
    "https://en.wikipedia.org/wiki/Melania_Trump",
    "https://en.wikipedia.org/wiki/Alexander_Hamilton",
    "https://en.wikipedia.org/wiki/Benjamin_Franklin",
    "https://en.wikipedia.org/wiki/John_Jay",
    "https://en.wikipedia.org/wiki/Aaron_Burr",
    "https://en.wikipedia.org/wiki/Samuel_Adams",
    "https://en.wikipedia.org/wiki/Elbridge_Gerry",
    "https://en.wikipedia.org/wiki/George_Wythe",
    "https://en.wikipedia.org/wiki/Roger_Sherman",
    "https://en.wikipedia.org/wiki/Thomas_Paine",
    "https://en.wikipedia.org/wiki/Lucius_Quinctius_Cincinnatus",
    ]
#url = "https://en.wikipedia.org/wiki/George_Washington"

index = 1
corpus = {}
corpus['presdoc'] = []
def build_document_json(id, url, title, body):
    document = {}
    document['presdoc'] = {
        'id': id,
        'url': url,
        'title': title,
        'body': body
    }
    corpus['presdoc'].append(document)
#    jd = json.dumps(document)
#    return jd;

rgx_list = ['\[[0-9a-zA-Z]*\]', '\[citation needed\]', '.mw-parser-output', '.toclimit-[0-9]*', '.toclevel-[0-9]* ul,',
           '.toclevel-6 ul', '.tmulti', '.trow', '.thumb[a-zA-Z]*', '.text-align-[a-zA-Z]*', '\{[a-zA-Z0-9\:\%\-\;\!\.\,]*\}',
            '\@media', 'all\ and\ \(max\-width\:720px\)', '.tsingle', '.theader',
           '\^[a-zA-Z0-9\:\%\-\;\!\.\,]*', '\xa0', '[1-9]*\ References', '[1-9]*\ Notes' ]

def clean_text(rgx_list, text):
    new_text = text
    for rgx_match in rgx_list:
        new_text = re.sub(rgx_match, '', new_text)
    return new_text

def getNgrams(content, n):
  content = content.split(' ')
  output = []
  for i in range(len(content)-n+1):
    output.append(content[i:i+n])
  return output

def build_json_file(url):
    html = urlopen(url)
    bs = BeautifulSoup(html, 'html.parser')
    content = bs.find('div', {'id':'mw-content-text'}).get_text()
    content = clean_text(rgx_list, content)
    ref = content.find('References')
    note = content.find('Notes')
    if(ref>0):
        content=content[:ref]
    if(note>0 & note<len(content)):
        content=content[:note]

    title_list = url.split('/')
    title = title_list[len(title_list) - 1]
    print(title_list)
    print(title)
#    filename = 'PresidentJson\\' + title +'json.txt'
    build_document_json(index, url, title, content)
    
for url in urls:
    build_json_file(url)
    if(index==24):
        index = index+2
    else:
        index = index+1
    with open("presidentcorpus.txt", "w") as f:
        json.dump(corpus, f)
#        f.write(document)
