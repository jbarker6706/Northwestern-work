# Select Movies and Construct Input and Output Sequences

# Programmed by Thomas W. Miller (2019-02-11)

# When TEST = True one movie is slected --- id:m42  title:casablanca
TEST = False 

# The initial data come from the Cornell Movie Dialogs database:
# http://www.cs.cornell.edu/~cristian/Cornell_Movie-Dialogs_Corpus.html 

# This  version of the program is set up to generate
# input/output data for sequence-to-sequence language models,
# as needed for conversational agents or chatbots.
# Romantic comedies were chosen as a basis for training data.
# There are 63 romantic comedies and input and output
# output files with 28,964 lines each, corresponding to
# interactions between to speakers or roles in the movies.

# Two files can serve as input to seq2seq models for chatbots:
#      movies-sequence-input.txt
#      movies-sequence-output.txt

# Alternatively, students may choose to use other movie genres or
# the entire Cornell Movie Dialogs corpus. Note that training a
# language model on the entire corpus could take a good deal of 
# time on a CPU-only (no GPU) device.

# Input text files for test runs
# casablanca_characters_metadata.txt  (reserve for future use)
# casablanca_conversations.txt  (line numbers for each conversation)
# casablanca_lines.txt  (line numbers and script text)
# casablanca_titles_metadata.txt  (casablanca summary data)

# Output text files for test runs
# casablanca-sequence-input.txt  (first speaker script words)
# casablanca-sequence-output.txt  (second speaker script words)

# Input text files for standard runs across many movies
# movies_characters_metadata.txt  (reserve for future use)
# movies_conversations.txt  (line numbers for each conversation)
# movies_lines.txt  (line numbers and script text)
# movies_titles_metadata.txt  (casablanca summary data)

# Output text files for standard runs across many movies
# movies-sequence-input.txt  (first speaker script words)
# movies-sequence-output.txt  (second speaker script words)

# Standard runs involve the selection of one or more genres by name(s)
# Select genres by list of names or set select = [] to select all movies
# Possible genres include:  'action', 'adventure', 'adult', biography',  
# 'comedy', 'crime', 'drama', 'drama', 'family', 'fantasy', 'horror',  
# 'musical', 'mystery', 'romance', 'sci-fi', 'thriller', 'war', 'western'

# selected_genres = [] # 616 total movies, 221566 input/output lines

# 5 movies, including casablanca, 2151 input/output sequence lines
# selected_genres = ['drama', 'romance', 'war'] 

# 63 romantic comedies, 28964 input/output sequence lines
# selected_genres = ['romance', 'comedy'] 

# selected_genres = ['western'] # 12 westerns, 4416 input/output lines
# selected_genres = ['war'] # 22 war movies, 7024 input/output lines
# selected_genres = ['biography'] # 25 biographies, 10321 input/output lines
# selected_genres = ['sci-fi'] # 112 'sci-fi' movies, 30829 input/output lines
# selected_genres = ['crime'] # 145 crime movies, 54962 input/output lines
# selected_genres = ['action'] # 157 action movies, 46093 input/output lines

# Movie metadata for the selected genres within the Cornell corpus are
# provided in the selected-movies-data.csv files.
# Metadata for the complete corpus are provided in total_movies_data.csv file.

# This is where we specify the desired type of movie for the study
selected_genres = ['romance', 'comedy'] 


# Selected movie must meet all selected genres
def get_moviedata(select = [], test = False):
    idselected = []; titleselected = [] 
    if test:
        movie_titles = open('casablanca_titles_metadata.txt').read().split('\n')
    else:        
        movie_titles = open('movie_titles_metadata.txt').read().split('\n')
    mfile = open('selected-movies-data.csv', 'wt') 
    mfile.writelines('id,title,year,rating,votes,genres')    
    for line in movie_titles[:-1]:       
        id = line.split(' +++$+++ ')[0]
        title = line.split(' +++$+++ ')[1]
        year = line.split(' +++$+++ ')[2]
        rating = line.split(' +++$+++ ')[3]
        votes = line.split(' +++$+++ ')[4]
        _line = line.split(' +++$+++ ')[-1][1:-1].replace("'","").replace(" ","")
        genres = _line.split(',') # convert string to list
        if set(select).issubset(set(genres)):
            idselected.append(id)
            titleselected.append(title)
            mfile.writelines('\n'+str(id)+','+str(title)+','+\
                str(year)+','+str(rating)+','+str(votes)+','+str(genres))
    mfile.close()                    
    return idselected, titleselected

idselected, titleselected = get_moviedata(select = selected_genres, test = TEST)

print('\n\n', len(idselected), 'selected movie ids and titles match', 
    selected_genres, '\n')
for i in range(len(idselected)):
    print('id:', idselected[i], 'title:', titleselected[i])

# id2line and get_conversations adapted from Suriyadeepan repository at
#  https://github.com/suriyadeepan/datasets

# Create dictionary of line_ids and text of line_ids
# Complete dictionary for all movies regardless of selections
def get_id2line(test = False):
    if test:
        lines = open('casablanca_lines.txt').read().split('\n')
    else:        
        lines = open('movie_lines.txt').read().split('\n')
    id2line = {}
    for line in lines[:-1]:
        _line = line.split(' +++$+++ ')
        if len(_line) == 5:
            id2line[_line[0]] = _line[4]
    return id2line

id2line = get_id2line(test = TEST)

# Create list of [list of line_ids] for selected movies only
# This list of lists is for all conversations in selected movies
# Note that the order of line numbers within each conversation
# are meaningful and critical to seq2seq modeling
# But, curiously for the movie dialogues database, it appears
# that the order of conversations within movies is not meaningful
# Accordingly, the reconstructed script for a movie may bear
# little resemblance to the actual script for that movie 
def get_conversations(idselected, test = False):
    if test:
        conv_lines = open('casablanca_conversations.txt').read().split('\n')
    else:        
        conv_lines = open('movie_conversations.txt').read().split('\n')
    convs = []
    for line in conv_lines[:-1]:
        id = line.split(' +++$+++ ')[2][:]  
        if set([id]).issubset(set(idselected)):
            _line = line.split(' +++$+++ ')[-1][1:-1].replace("'","").replace(" ","")
            convs.append(_line.split(',')) # string to list for list of lists
    return convs

convs = get_conversations(idselected, test = TEST)

# Create input-output pairs for seq2seq model 
def input_output(convs, id2line):
    input = []; output = []
    for conv in convs:
        for i in range(len(conv)-1):
            input.append(id2line[conv[i]])
            output.append(id2line[conv[i+1]])
    return input, output

input, output = input_output(convs, id2line)

# Route input and output lines/word sequences to files for seq2seq modeling
if not TEST:
    with open('movies-sequence-input.txt', 'wt') as f:
        f.writelines(str(input[i]) + "\n" for i in range(len(input)-1))
        f.writelines(str(input[-1]))
    with open('movies-sequence-output.txt', 'wt') as f:
        f.writelines(str(output[i]) + "\n" for i in range(len(output)-1))  
        f.writelines(str(output[-1])) 

# We reconstruct scripts to check coding during development 
# Note that conversations do not match actual movie script sequence
# It is sequences within conversations that matter for the seq2seq model
# The next two functions used in TEST mode only... for casablanca
def reconstruct_script(convs, id2line):
    script = []
    for conv in convs:
        for i in range(len(conv)):
            script.append(id2line[conv[i]])
    return script    

def print_script(script, limit = True):
    if limit:
        maxlines = 20
    else:
        maxlines = len(script)    
    for lineno in range(maxlines):
        print(script[lineno])

# Print out the script for casablanca if TEST run
# Also route full input and output sequences to files
if TEST: 
    script = reconstruct_script(convs, id2line)
    print('\nScript of Casablanca')
    print_script(script, limit = False)
    print('\n\nRendering of input-output conversations for seq2seq modeling (first 20 lines)\n')
    for i in range(20):    
        print(input[i], ' ---> ', output[i]) 
    with open('casablanca-sequence-input.txt', 'wt') as f:
        f.writelines(str(input[i]) + "\n" for i in range(len(input)-1))
        f.writelines(str(input[-1]))
    with open('casablanca-sequence-output.txt', 'wt') as f:
        f.writelines(str(output[i]) + "\n" for i in range(len(output)-1))  
        f.writelines(str(output[-1])) 